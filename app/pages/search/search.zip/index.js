/**
 * create: 2017-6-16 21:00:19
 * author: xuxufei
 * e-mail: xuxufei@2144.cn
 * description: 搜索
 */

import React, { Component } from 'react';

import Home from './home';
import Result from './result';

class Search extends Component {
	static navigationOptions = {
		header : null
	};
	constructor(props) {
		super(props);
	}
	render() {
		let { navigation } = this.props;
		let { params } = navigation.state;
		return (
			params && params.name ? (
				<Result navigation={ navigation } />
			) : (
				<Home navigation={ navigation } />
			)
		);
	}
};

export default Search;